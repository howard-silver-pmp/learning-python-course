# Bring in the RANDOM module to use the randint() function to generate a random number
import random

# Top loop: run the full game again if the player wants to play again
while True:

    # Show the Welcome message
    print("Welcome to the Guessing Game!")
    print("-----------------------------")

    # Store the secret number the player is trying to guess
    secret_number = random.randint(1, 10)

    # Track whether the player has guessed correctly
    # The game starts with this set to False because the player has not won yet
    is_correct = False

    # Count how many guesses the player has made
    # The count starts at 0 because the player has not guessed yet
    attempts = 0

    # Ask the player to choose a difficulty level for this round
    difficulty = input("Choose a difficulty level (easy / medium / hard): ")

    # Set the number of guesses based on the difficulty
    if difficulty == "easy":
        # Easy mode gives the player more guesses
        max_attempts = 5
    elif difficulty == "medium":
        # Medium mode uses the normal number of guesses
        max_attempts = 3
    else:
        # Any other answer uses hard mode for now
        max_attempts = 2

    # Show the player which difficulty is active
    print("Difficulty:", difficulty)

    # Show the player how many guesses they get
    print("Guesses available:", max_attempts)

    # Keep running the game while the player has not guessed correctly
    # and still has guesses left
    while is_correct == False and attempts < max_attempts:
        # Ask the player to enter a guess
        # input() gets text from the player
        # int() changes that text into a number
        guess = int(input("Enter your guess: "))

        # Increase the guess count by 1
        attempts = attempts + 1

        # Check whether the player's guess matches the secret number
        if guess == secret_number:
            # Show the winning message
            print("Correct! You guessed the number.")

            # Show how many guesses the player used
            print("Total guesses:", attempts)

            # Mark that the player guessed correctly so the loop can stop
            is_correct = True
            break
        elif guess > secret_number:
            # This message displays when the guess is greater than the secret number
            print("Too high.")
        else:
            # This message displays when the guess is lower than the secret number
            print("Too low.")

        # Calculate how many guesses the player has left
        remaining = max_attempts - attempts

        # Only show remaining guesses if the player has not already won
        if is_correct == False:
            # Show how many guesses remain
            print("Guesses remaining:", remaining)

    # After the loop ends, check whether the player lost
    if is_correct == False:
        # Show the losing message
        print("Game over. The number was", secret_number)

    # Ask whether the player wants to play the full game again
    play_again = input("Play again? (Y/n): ")

    # Stop the replay loop only if the player clearly says no
    if play_again == "n":
        # break exits the top loop, so the whole program ends
        break
